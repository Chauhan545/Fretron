import java.util.*;

public class Ques1FlightPath {

    // Class to represent a coordinate point
    static class Coordinate {
        int x, y;
        
        Coordinate(int x, int y) {
            this.x = x;
            this.y = y;
        }
        
        public String toString() {
            return "(" + x + "," + y + ")";
        }
        
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Coordinate that = (Coordinate) o;
            return x == that.x && y == that.y;
        }
        
        public int hashCode() {
            return Objects.hash(x, y);
        }
    }

    // Class to represent a flight path
    static class FlightPath {
        List<Coordinate> path;

        FlightPath(List<Coordinate> path) {
            this.path = path;
        }

        public List<Coordinate> getPath() {
            return path;
        }

        public void addCoordinate(Coordinate coord) {
            this.path.add(coord);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<FlightPath> flights = new ArrayList<>();
        
        System.out.println("Enter the number of flights:");
        int numFlights = scanner.nextInt();
        scanner.nextLine(); 

        for (int i = 0; i < numFlights; i++) {
            System.out.println("Enter coordinates for flight " + (i + 1) + " (format: x,y):");
            List<Coordinate> path = new ArrayList<>();
            String line = scanner.nextLine();
            String[] coords = line.split(" ");
            for (String coord : coords) {
                String[] xy = coord.split(",");
                int x = Integer.parseInt(xy[0]);
                int y = Integer.parseInt(xy[1]);
                path.add(new Coordinate(x, y));
            }
            flights.add(new FlightPath(path));
        }

        // Display the paths
        displayPaths(flights);
    }

    private static void displayPaths(List<FlightPath> flights) {
        Set<Coordinate> occupied = new HashSet<>();
        
        for (int i = 0; i < flights.size(); i++) {
            FlightPath flight = flights.get(i);
            System.out.println("Flight " + (i + 1) + " path:");
            for (Coordinate coord : flight.getPath()) {
                if (occupied.contains(coord)) {
                    System.out.println("Conflict at " + coord);
                } else {
                    occupied.add(coord);
                    System.out.println(coord);
                }
            }
            System.out.println();
        }
    }
}
