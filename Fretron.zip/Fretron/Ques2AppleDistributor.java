import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Ques2AppleDistributor {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        List<Integer> apples = new ArrayList<>();
        
        // Taking input for apple weights
        System.out.println("Enter apple weight in gram (-1 to stop) ");
        while (true) {
            int weight = scanner.nextInt();
            if (weight == -1) {
                break;
            }
            apples.add(weight);
        }
        
        Collections.sort(apples, Collections.reverseOrder());

        double ramProportion = 0.5;   
        double shamProportion = 0.3;  
        double rahimProportion = 0.2; 
      
        int totalWeight = apples.stream().mapToInt(Integer::intValue).sum();
        
        double ramTargetWeight = totalWeight * ramProportion;
        double shamTargetWeight = totalWeight * shamProportion;
        double rahimTargetWeight = totalWeight * rahimProportion;
        
        List<Integer> ramApples = new ArrayList<>();
        List<Integer> shamApples = new ArrayList<>();
        List<Integer> rahimApples = new ArrayList<>();

        for (int weight : apples) {
            if (ramTargetWeight > 0 && ramTargetWeight >= weight) {
                ramApples.add(weight);
                ramTargetWeight -= weight;
            } else if (shamTargetWeight > 0 && shamTargetWeight >= weight) {
                shamApples.add(weight);
                shamTargetWeight -= weight;
            } else {
                rahimApples.add(weight);
                rahimTargetWeight -= weight;
            }
        }
        
        System.out.println("Distribution Result=");
        System.out.println("Ram= " + ramApples);
        System.out.println("Sham= " + shamApples);
        System.out.println("Rahim= " + rahimApples);
        
        scanner.close();
    }
}


