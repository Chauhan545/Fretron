import java.util.*;

public class Ques3SpecializedCastle {

    static class Coordinate {
        int x, y;

        Coordinate(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public String toString() {
            return "(" + x + "," + y + ")";
        }

        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            Coordinate that = (Coordinate) obj;
            return x == that.x && y == that.y;
        }

        public int hashCode() {
            return Objects.hash(x, y);
        }
    }

    static class Path {
        List<Coordinate> steps;

        Path() {
            steps = new ArrayList<>();
        }

        Path(List<Coordinate> steps) {
            this.steps = new ArrayList<>(steps);
        }

        void addStep(Coordinate step) {
            steps.add(step);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("Start: ").append(steps.get(0));
            for (int i = 1; i < steps.size(); i++) {
                sb.append(" -> ").append(steps.get(i));
            }
            return sb.toString();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter number of soldiers= ");
        int numSoldiers = scanner.nextInt();
        scanner.nextLine(); 

        Set<Coordinate> soldiers = new HashSet<>();
        for (int i = 0; i < numSoldiers; i++) {
            System.out.print("Enter coordinates for soldier " + (i + 1) + ": ");
            String[] parts = scanner.nextLine().split(",");
            int x = Integer.parseInt(parts[0]);
            int y = Integer.parseInt(parts[1]);
            soldiers.add(new Coordinate(x, y));
        }

        System.out.print("Enter the coordinates for your special castle: ");
        String[] castleParts = scanner.nextLine().split(",");
        Coordinate castle = new Coordinate(Integer.parseInt(castleParts[0]), Integer.parseInt(castleParts[1]));

        List<Path> paths = new ArrayList<>();
        findPaths(castle, castle, soldiers, new HashSet<>(), new Path(), paths);

        System.out.println("Thanks. There are " + paths.size() + " unique paths for your special_castle");
        for (int i = 0; i < paths.size(); i++) {
            System.out.println("\nPath " + (i + 1) + "=======");
            System.out.println(paths.get(i));
        }

        scanner.close();
    }

    private static void findPaths(Coordinate current, Coordinate start, Set<Coordinate> soldiers, Set<Coordinate> visited, Path path, List<Path> paths) {
        if (soldiers.isEmpty() && current.equals(start)) {
            paths.add(new Path(path.steps));
            return;
        }

        List<Coordinate> toRemove = new ArrayList<>();
        for (Coordinate soldier : soldiers) {
            if (soldier.x == current.x && soldier.y > current.y) {
                toRemove.add(soldier);
                Path newPath = new Path(path.steps);
                newPath.addStep(new Coordinate(soldier.x, soldier.y));
                findPaths(new Coordinate(soldier.x, soldier.y), start, new HashSet<>(soldiers), visited, newPath, paths);
            }
        }
        soldiers.removeAll(toRemove);

        for (Coordinate soldier : soldiers) {
            if (soldier.y == current.y && soldier.x < current.x) {
                Coordinate jump = new Coordinate(soldier.x, current.y);
                if (!visited.contains(jump)) {
                    Path newPath = new Path(path.steps);
                    newPath.addStep(jump);
                    findPaths(jump, start, new HashSet<>(soldiers), visited, newPath, paths);
                }
            }
        }
    }
}
